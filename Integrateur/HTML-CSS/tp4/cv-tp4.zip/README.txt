README

        FORMATION	: INTEGRATION WEB

        AUTEUR		: Vincent RAINE

        ACTIVITE	: HTML5 - Semaine 4

        SUJET		: Adapter son CV en responsive


STRUCTURE DU DOSSIER:

		index.html
		/webroot
				/css	:	Feuilles de styles CSS
				/fonts	:	Fonts utilisées
				/img 	:	Images
				/js		:	Scripts Javascript
